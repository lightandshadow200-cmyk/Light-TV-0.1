package com.lighttv.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 11, 18)
    private val text = Color.rgb(245, 247, 252)
    private val muted = Color.rgb(172, 184, 207)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34), dp(18), dp(34), dp(20))
            setBackgroundColor(bg)
            isFocusable = true
            isFocusableInTouchMode = true
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(14))
        }
        header.addView(label("◉  Light TV", 25, text, true), LinearLayout.LayoutParams(0, dp(52), 1f))
        header.addView(navButton("Trang chủ") { buildUi() })
        header.addView(navButton("Ứng dụng") { showApps() })
        header.addView(navButton("Cài đặt") { openSettings() })
        header.addView(label(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 18, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(18), 0, 0, 0)
        })
        root.addView(header)

        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(18), dp(20), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(27, 47, 76), Color.rgb(16, 20, 31), Color.rgb(53, 42, 55))).apply { cornerRadius = dp(24).toFloat() }
        }
        hero.addView(label("LIGHT TV ORIGINAL", 13, muted, true))
        hero.addView(label("Khám phá thế giới\ngiải trí của bạn", 32, text, true).apply { setPadding(0, dp(10), 0, dp(8)) })
        hero.addView(label("Giao diện TV tối giản. Tập trung vào nội dung.", 16, muted, false))
        val heroActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(18), 0, 0) }
        heroActions.addView(actionButton("Mở ứng dụng") { showApps() })
        heroActions.addView(actionButton("Cài đặt hệ thống") { openSettings() }.apply { setPadding(dp(18), dp(12), dp(18), dp(12)) })
        hero.addView(heroActions)
        content.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(210)))
        content.addView(label("Ứng dụng của bạn", 22, text, true).apply { setPadding(0, dp(22), 0, dp(10)) })
        val appStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val common = listOf("YouTube" to "com.google.android.youtube.tv", "Netflix" to "com.netflix.ninja",
            "Prime Video" to "com.amazon.amazonvideo.livingroom", "Disney+" to "com.disney.disneyplus", "Spotify" to "com.spotify.tv.android")
        var added = 0
        common.forEach { (name, pkg) -> if (launchIntent(pkg) != null) { appStrip.addView(appTile(name, pkg)); added++ } }
        if (added == 0) appStrip.addView(label("Chưa tìm thấy ứng dụng mẫu. Chọn ‘Tất cả ứng dụng’ để xem ứng dụng đã cài.", 15, muted, false))
        appStrip.addView(appTile("Tất cả ứng dụng", "__all__"))
        val appScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(appStrip) }
        content.addView(appScroll)
        content.addView(label("Truy cập nhanh", 22, text, true).apply { setPadding(0, dp(20), 0, dp(10)) })
        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        shortcuts.addView(actionButton("⚙  Cài đặt Android") { openSettings() })
        shortcuts.addView(actionButton("▦  Tất cả ứng dụng") { showApps() })
        content.addView(shortcuts)
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        root.requestFocus()
    }

    private fun showApps() {
        root.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("Ứng dụng", 30, text, true), LinearLayout.LayoutParams(0, dp(60), 1f))
        header.addView(navButton("← Trang chủ") { buildUi() })
        root.addView(header)
        val scroll = ScrollView(this)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pm = packageManager
        val apps = try {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
                .sortedBy { pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }
        } catch (_: Exception) { emptyList() }
        if (apps.isEmpty()) grid.addView(label("Không tìm thấy ứng dụng có thể mở.", 18, muted, false))
        apps.chunked(4).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { app ->
                val name = pm.getApplicationLabel(app).toString()
                val tile = appTile(name, app.packageName)
                row.addView(tile, LinearLayout.LayoutParams(0, dp(92), 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            }
            repeat(4 - group.size) { row.addView(View(this), LinearLayout.LayoutParams(0, dp(92), 1f)) }
            grid.addView(row)
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun appTile(name: String, packageName: String): TextView = label(name, 17, text, true).apply {
        gravity = Gravity.CENTER
        maxLines = 2
        ellipsize = android.text.TextUtils.TruncateAt.END
        background = tileBackground(false)
        isFocusable = true
        isClickable = true
        setPadding(dp(8), dp(8), dp(8), dp(8))
        setOnFocusChangeListener { v, focused -> v.background = tileBackground(focused) }
        setOnClickListener {
            if (packageName == "__all__") showApps()
            else {
                val intent = launchIntent(packageName)
                if (intent != null) startActivity(intent) else Toast.makeText(this@MainActivity, "Ứng dụng chưa được cài đặt", Toast.LENGTH_SHORT).show()
            }
        }
        setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) { performClick(); true } else false
        }
    }

    private fun navButton(title: String, action: () -> Unit): TextView = actionButton(title, action).apply {
        textSize = 15f
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = tileBackground(false)
        setOnFocusChangeListener { v, focused -> v.background = tileBackground(focused) }
    }

    private fun actionButton(title: String, action: () -> Unit): TextView = label(title, 16, text, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(12), dp(16), dp(12))
        background = tileBackground(false)
        isFocusable = true
        isClickable = true
        setOnFocusChangeListener { v, focused -> v.background = tileBackground(focused) }
        setOnClickListener { action() }
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun tileBackground(focused: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(if (focused) 18 else 14).toFloat()
        setColor(if (focused) Color.rgb(65, 79, 105) else Color.rgb(27, 32, 44))
        if (focused) setStroke(dp(2), Color.rgb(235, 241, 255))
    }

    private fun launchIntent(pkg: String) = try { packageManager.getLaunchIntentForPackage(pkg) } catch (_: Exception) { null }
    private fun openSettings() { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "Không mở được Cài đặt", Toast.LENGTH_SHORT).show() } }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
